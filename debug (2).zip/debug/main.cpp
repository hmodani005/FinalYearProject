#include<stdio.h>
#include<iostream>
#include<vector>
#include<conio.h>
#include<algorithm>
#include<map>
#include<set>
using namespace std;
#define THRESHOLD 0.5
#define PSEUDO_TRANS_PROB 0.0
#define PSEUDO_EMI_PROB 0.0

typedef struct transitiontype
{
    struct statetype* ptr;
    double prob;
    transitiontype(): prob(PSEUDO_TRANS_PROB){}
} transition;

typedef struct statetype
{
    char type;
    vector<double> dp;
    struct transitiontype toinsert,todelete,tomatch;
    struct statetype *frominsert,*fromdelete,*frommatch;
    double a,c,t,g;
    statetype(): a(PSEUDO_EMI_PROB),c(PSEUDO_EMI_PROB),t(PSEUDO_EMI_PROB),g(PSEUDO_EMI_PROB) {}
} state;

void initialize(vector<int> &vec, int val)
{
    for(int i=0; i<vec.size(); i++)
    {
        vec[i]=val;
    }
    return;
}

int getmax(vector<int> count)
{
    int i,maxindex,max=0;
    for(i=0; i<count.size(); i++)
    {
        if(count[i]>max)
        {
            max= count[i];
            maxindex= i;
        }
    }
    return maxindex;
}

int getnucleobase(char base)         // '-' = 0 , 'a' = 1, 'c'= 2, 't' = 3, 'g' = 4  //
{
    int val=0;
    if(base=='a' || base=='A')
    {
        val=1;
    }
    else if( base =='c' || base=='C')
    {
        val=2;
    }
    else if( base =='t' || base=='T')
    {
        val=3;
    }
    else if( base =='g' || base=='G')
    {
        val=4;
    }
    return val;
}

int gethmmlength(string modelstring)
{
    int count=0;
    for(int i=0;i<modelstring.length();i++)
    {
        if(modelstring[i]=='M')
        {
            count++;
        }
    }
    return count;
}
string makemodelstring(vector<string> sequence)    //size of all strings should be equal
{
    vector<int> count(5);
    int i,j,maxbase,strlen= sequence[0].length(),sqlen=sequence.size();
    string modelstring;
    for(j=0; j<strlen; j++)
    {
        initialize(count,0);
        for(i=0; i<sqlen; i++)
        {
            count[getnucleobase(sequence[i][j])]++;
        }
//        for(i=0;i<5;i++)
//        {
//            cout<<count[i]<<" ";
//        }
//        cout<<endl;
        maxbase= getmax(count);
//        cout<<maxbase<<"------------\n";
        if(maxbase==0 || (double)count[maxbase]/(double)sqlen< THRESHOLD)
        {
            modelstring += 'I';
        }
        else
        {
            modelstring += 'M';
        }
    }
    return modelstring;
}

state* createstate(char type)
{
    state* tmp;
    if(type=='S')
    {
        tmp = new state();
        tmp->type = 'S';
        tmp->frominsert = tmp->fromdelete = tmp->frommatch = NULL;
        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
    }
    else if(type=='I')
    {
        tmp = new state();
        tmp->type = 'I';
        tmp->frominsert = tmp->fromdelete = tmp->frommatch = NULL;
        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
        tmp->frominsert = tmp;              //Insert->Insert Link
        (tmp->toinsert).ptr = tmp;
    }
    else if(type=='M')
    {
        tmp = new state();
        tmp->type = 'M';
        tmp->frominsert = tmp->fromdelete = tmp->frommatch = NULL;
        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
    }
    else if(type=='D')
    {
        tmp = new state();
        tmp->type = 'D';
        tmp->frominsert = tmp->fromdelete = tmp->frommatch = NULL;
        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
    }
    else if(type=='E')
    {
        tmp = new state();
        tmp->type = 'E';
        tmp->frominsert = tmp->fromdelete = tmp->frommatch = NULL;
        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
//        (tmp->toinsert).ptr = (tmp->todelete).ptr = (tmp->tomatch).ptr = NULL;
    }
    return tmp;
}

state* makemodel(string modelstring)
{
    state *start=NULL , *end;
    int i,j;
    start = createstate('S');
    state* insert0 = createstate('I');

    (start->toinsert).ptr =insert0;     //start-> I0
    insert0->frommatch = start;

    state *mat,*ins,*del, *prevmat, *previns, *prevdel;
    mat = createstate('M');
    ins = createstate('I');
    del = createstate('D');

    mat->frommatch = start;         //start->M1
    (start->tomatch).ptr = mat;

    del->frommatch = start;         //start->D1
    (start->todelete).ptr = del;

    mat->frominsert = insert0;      //I0->M1
    (insert0->tomatch).ptr = mat;

    ins->frommatch = mat;           //M1->I1
    (mat->toinsert).ptr = ins;

    del->frominsert = insert0;      //I0->D1
    (insert0->todelete).ptr = del;

    ins->fromdelete = del;          //D1->I1
    (del->toinsert).ptr = ins;

    i=0;
    while(i<modelstring.length() && modelstring[i]=='I')     //find first M
    {
        i++;
    }
    while(i<modelstring.length() )
    {
        i++;
        while(i<modelstring.length() && modelstring[i]=='I')      //loop till second M
        {
            i++;
        }
        if(i<modelstring.length())
        {
            prevmat = mat;
            previns = ins;
            prevdel = del;
            mat = createstate('M');
            ins = createstate('I');
            del = createstate('D');

            mat->frominsert = previns;          //I(i)->M(i+1)
            (previns->tomatch).ptr = mat;

            mat->frommatch = prevmat;           //M(i)->M(i+1)
            (prevmat->tomatch).ptr = mat;

            mat->fromdelete = prevdel;          //D(i)->M(i+1)
            (prevdel->tomatch).ptr= mat;

            del->frommatch= prevmat;            //M(i)->D(i+1)
            (prevmat->todelete).ptr= del;

            del->frominsert= previns;           //I(i)->D(i+1)
            (previns->todelete).ptr= del;

            del->fromdelete= prevdel;           //D(i)->D(i+1)
            (prevdel->todelete).ptr= del;

            ins->frommatch= mat;                 //M(i+1)->I(i+1)
            (mat->toinsert).ptr= ins;

            ins->fromdelete= del;                //D(i+1)->I(i+1)
            (del->toinsert).ptr= ins;

        }

    }
    end = createstate('E');

    end->frommatch = mat;       //M->End
    (mat->tomatch).ptr = end;

    end->frominsert = ins;      //I->End
    (ins->tomatch).ptr = end;

    end->fromdelete = del;      //D->End
    (del->tomatch).ptr = end;

    return start;
}

void calcemissionprob(state* start, vector<string> sequence, string modelstring)
{
    state* current = start;
    int i,j,strlen=sequence[0].length(),num_seq=sequence.size();
    vector<int> count(5);
    initialize(count,0);
    for(j=0; j<strlen; j++)
    {
        for(i=0; i<num_seq; i++)
        {
            count[getnucleobase(sequence[i][j])]++;
        }
        if(modelstring[j]=='M')
        {
            current = (current->tomatch).ptr;
            current->a += (double)count[1]/(double)num_seq;
            current->c += (double)count[2]/(double)num_seq;
            current->t += (double)count[3]/(double)num_seq;
            current->g += (double)count[4]/(double)num_seq;
            initialize(count,0);
        }
        else
        {
            if(j+1<strlen && modelstring[j+1]=='I')
            {
                //Continue
            }
            else
            {
                current = (current->toinsert).ptr;
                current->a += (double)count[1]/(double)num_seq;
                current->c += (double)count[2]/(double)num_seq;
                current->t += (double)count[3]/(double)num_seq;
                current->g += (double)count[4]/(double)num_seq;
                initialize(count,0);
            }
        }
    }
    return;
}


double match_match(int m1, int m2, vector<string> sequence)
{
    double prob=1.0;
    int i,j,found,num=0,dnm=0;

    for(j=0;j<sequence.size();j++)
    {
        found=0;
        if(sequence[j][m1] !='-' )
        {
            dnm++;
            for(i=m1+1;i<m2;i++)
            {
                if(sequence[j][i]!='-')
                {
                    found=1;
                }
            }
            if(found!=1 && sequence[j][m2]!='-')
            {
                num++;
            }
        }

    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}
double match_insert(int m1, int m2, vector<string> sequence)
{
    double prob=1.0;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=0;
        if(sequence[j][m1]!='-')
        {
            dnm++;
            for(i=m1+1;i<m2;i++)
            {
                if(sequence[j][i]!='-')
                {
                    found=1;
                }
            }
        }
        num += found;
    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}
double match_delete(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=1;
        if(sequence[j][m1]!='-')
        {
            dnm++;
            for(i=m1+1;i<=m2;i++)
            {
                if(sequence[j][i]!='-')
                {
                    found=0;
                }
            }
            num += found;
        }
    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}
double insert_match(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=0;
        for(i=m1+1;i<m2;i++)
        {
            if(sequence[j][i]!='-')
            {
                found=1;
                dnm++;
            }
        }
        if(sequence[j][m2]!='-')
        {
            num += found;
        }
    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

double insert_delete(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=0;
        for(i=m1+1;i<m2;i++)
        {
            if(sequence[j][i]!='-')
            {
                found=1;
                dnm++;
            }
        }
        if(sequence[j][m2]=='-')
        {
            num += found;
        }
    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

double insert_insert(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=0;
        for(i=m1+1;i<m2;i++)
        {
            if(sequence[j][i]!='-')
            {
                num++;
                dnm++;
                found=1;
            }
        }
        if(found)
        {
            num--;
        }
    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

double delete_insert(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=0;
        if(sequence[j][m1]=='-')
        {
            dnm++;
            for(i=m1+1;i<m2 && found==0;i++)
            {
                if(sequence[j][i]!='-')
                {
                    found=1;
                }
            }
            num += found;
        }

    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

double delete_match(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=1;
        if(sequence[j][m1]=='-')
        {
            dnm++;
            for(i=m1+1;i<m2 && found==1;i++)
             {
                if(sequence[j][i]!='-')
                {
                    found=0;
                }
            }
            if(sequence[j][m2]!='-')
            {
                num += found;
            }
        }

    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

double delete_delete(int m1, int m2, vector<string> sequence)
{
    double prob;
    int i,j,num=0,dnm=0,found;
    for(j=0;j<sequence.size();j++)
    {
        found=1;
        if(sequence[j][m1]=='-')
        {
            dnm++;
            for(i=m1+1;i<=m2 && found==1;i++)
            {
                if(sequence[j][i]!='-')
                {
                    found=0;
                }
            }
            num += found;
        }

    }
    if(dnm==0)
    {
        prob = 0;
    }
    else
    {
        prob= (double)num/(double)dnm;
    }
    return prob;
}

void calctransitionprob(state* start, vector<string> sequence, string modelstring)
{
    vector<string> modified_sequence;
    state* ins, *del, *mat;
    string s,modified_modelstring;
    modified_modelstring += 'M';
    modified_modelstring += modelstring;
    modified_modelstring += 'M';
    int i,j;
    for(i=0;i<sequence.size();i++)
    {
        s = 'a' + sequence[i] + 'a';
        modified_sequence.push_back(s);
    }
    //start and end case all matching cols to be added
    j=0;
    mat= start;
    ins= (start->toinsert).ptr;
    del= NULL;
    while(j+1<modified_modelstring.length())
    {
        i=j;
        j++;
        while(j<modified_modelstring.length() && modified_modelstring[j]!='M')
        {
            j++;
        }
        if(mat!=NULL)
        {
            (mat->tomatch).prob += match_match(i,j,modified_sequence);
            (mat->toinsert).prob += match_insert(i,j,modified_sequence);
            (mat->todelete).prob += match_delete(i,j,modified_sequence);
        }
        if(ins!=NULL)
        {
            (ins->todelete).prob += insert_delete(i,j,modified_sequence);
            (ins->tomatch).prob += insert_match(i,j,modified_sequence);
            (ins->toinsert).prob += insert_insert(i,j,modified_sequence);
        }
        if(del!=NULL)
        {
            (del->toinsert).prob += delete_insert(i,j,modified_sequence);
            (del->tomatch).prob += delete_match(i,j,modified_sequence);
            (del->todelete).prob += delete_delete(i,j,modified_sequence);
        }

        del= mat->todelete.ptr;
        mat= mat->tomatch.ptr;
        ins= mat->toinsert.ptr;
    }
    return;
}
double forwardalgo(state * start, string input, string modelstring)
{
	state* ins,*mat,*del, *prevmat=NULL, *prevdel=NULL, *previns=NULL;
	int t;
	for(t=0;t<=input.size();t++)
	{
		mat=start;
		ins=(start->toinsert).ptr ;
		del=NULL;
		previns=prevmat=prevdel=NULL;
		while(mat->type!='E')
		{
			double insprob=0.0, delprob=0.0, matprob=0.0;
			if(prevmat!=NULL)
			{
			    if(t>0)
				{
				    matprob += (prevmat->dp[t-1])* (prevmat->tomatch).prob;
				}
				delprob += (prevmat->dp[t]) * (prevmat->todelete).prob;
			}
			if(previns!=NULL)
			{
			    if(t>0)
				{
				    matprob += (previns->dp[t-1]) * (previns->tomatch).prob;
				}
				delprob += (previns->dp[t]) * (previns->todelete).prob;
			}
			if(prevdel!=NULL)
			{
				delprob += (prevdel->dp[t]) * (prevdel->todelete).prob;
				matprob += (prevdel->dp[t]) * (prevdel->tomatch).prob;
			}
			if(del!=NULL)
			{
				del->dp.push_back(delprob);
				insprob += del->dp[t] * (del->toinsert).prob;
			}
			if(ins!=NULL)
			{
			    if(t>0)
				{
				    insprob += ins->dp[t-1] * (ins->toinsert).prob;
				}
			}
			if(mat!=NULL)
			{
			    if(t>0)
				{
				    insprob += mat->dp[t-1] * (mat->toinsert).prob;
				}
			}
			if(input[t-1]=='a' || input[t-1]=='A')
			{
				insprob *= ins->a;
				matprob *= mat->a;
			}
			else if(input[t-1]=='c' || input[t-1]=='C')
			{
				insprob *= ins->c;
				matprob *= mat->c;
			}
			else if(input[t-1]=='t' || input[t-1]=='T')
			{
				insprob *= ins->t;
				matprob *= mat->t;
			}
			else if(input[t-1]=='g' || input[t-1]=='G')
			{
				insprob *= ins->g;
				matprob *= mat->g;
			}
			if(mat!=NULL)
			{
				if( mat->type != 'S')
				{
					mat->dp.push_back(matprob);
				}
				else
				{
					mat->dp.push_back(1.0);
				}
 			}
 			if(ins!=NULL)
 			{
 				ins->dp.push_back(insprob);
 			}
 			prevmat=mat;
            previns=ins;
            prevdel=del;
            del= (mat->todelete).ptr;
            mat= (mat->tomatch).ptr;
            ins= (mat->toinsert).ptr;
		}
	}
	double score = 0.0;
	score += prevmat->dp[t-1] * (prevmat->tomatch).prob;
	score += previns->dp[t-1] * (previns->tomatch).prob;
	score += prevdel->dp[t-1] * (prevdel->tomatch).prob;
	return score;
}
void print(state* temp)
{
    if(temp!=NULL)
    {
        cout<<temp->type<<endl;
//        cout<<(temp->tomatch).ptr<<endl<<(temp->toinsert).ptr<<endl<<(temp->todelete).ptr<<endl;
        printf("a=%lf c=%lf t=%lf g=%lf\n",temp->a, temp->c, temp->t , temp->g);
//        cout<<temp->frommatch<<endl<<temp->frominsert<<endl<<temp->fromdelete<<endl;
        cout<<(temp->tomatch).prob<<endl<<(temp->toinsert).prob<<endl<<(temp->todelete).prob<<endl;
        cout<<"******"<<endl;
    }
    else
    {
        cout<<"NULL"<<endl;
        cout<<"******"<<endl;
    }

    return ;
}

int main()
{
    vector<string> sequence;
    state* mat, * ins, *del, *start, *end , *prevmat , *previns , *prevdel , *curr;
    string tempstring,modelstring;
    int t;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>tempstring;
        sequence.push_back(tempstring);
    }
    modelstring = makemodelstring(sequence);
//    cout<<endl<<makemodelstring(sequence);
//    cout<<gethmmlength(modelstring);

//    mat= createstate('M');
//    ins= createstate('I');
//    del= createstate('D');
//    start=createstate('S');
//    end= createstate('E');

    curr = makemodel(modelstring);
    cout<<modelstring<<endl;
    calcemissionprob(curr,sequence,modelstring);
    calctransitionprob(curr,sequence,modelstring);
    prevmat = previns = prevdel = NULL;
    mat = curr;
    ins = (mat->toinsert).ptr;
    del = NULL;

    while(mat->type != 'E')
    {
        print(mat);
        print(ins);
        print(del);
        cout<<"----------------------"<<endl;

        prevmat=mat;
        previns=ins;
        prevdel=del;
        del= mat->todelete.ptr;
        mat= mat->tomatch.ptr;
        ins= mat->toinsert.ptr;
    }
    print(mat);
    print(ins);
    print(del);


    //Test emission
//    cout<<modelstring<<endl;
//    for(int i=0 ; i<modelstring.length(); i++)
//    {
//        if(modelstring[i]=='M')
//        {
//            curr = (curr->tomatch).ptr;
//            print(curr);
//            cout<<"----------"<<endl;
//        }
//        else
//        {
//            if(i+1<modelstring.length() && modelstring[i+1]=='I')
//            {
//                //Continue
//            }
//            else
//            {
//                curr = (curr->toinsert).ptr;
//                print(curr);
//                cout<<"----------"<<endl;
//            }
//        }
//    }
//    string input = "tacgatc";
    string input;
    cin>>input;
    cout<<endl<<endl<<forwardalgo(curr,input,modelstring);
    return 0;
}
