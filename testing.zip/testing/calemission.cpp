#include<stdio.h>
#include<iostream>
#include<vector>
#include<conio.h>
#include<algorithm>
#include<map>
#include<set>
#include "structure.h"
#define PSEUDO_TRANS_PROB 0.0
#define PSEUDO_EMI_PROB 0.0
void initialize(vector<int> &vec, int val)
{
    for(int i=0; i<vec.size(); i++)
    {
        vec[i]=val;
    }
    return;
}

void calcemissionprob(state* start, vector<string> sequence, string modelstring)
{
    state* current = start;
    int i,j,strlen=sequence[0].length(),num_seq=sequence.size();
    vector<int> count(5);
    initialize(count,0);
    for(j=0; j<strlen; j++)
    {
        for(i=0; i<num_seq; i++)
        {
            count[getnucleobase(sequence[i][j])]++;
        }
        if(modelstring[j]=='M')
        {
            current = (current->tomatch).ptr;
            current->a += (double)count[1]/(double)num_seq;
            current->c += (double)count[2]/(double)num_seq;
            current->t += (double)count[3]/(double)num_seq;
            current->g += (double)count[4]/(double)num_seq;
            initialize(count,0);
        }
        else
        {
            if(j+1<strlen && modelstring[j+1]=='I')
            {
                //Continue
            }
            else
            {
                current = (current->toinsert).ptr;
                int total= count[1]+count[2]+count[3]+count[4];
                current->a += (double)count[1]/(total);
                current->c += (double)count[2]/(total);
                current->t += (double)count[3]/(total);
                current->g += (double)count[4]/(total);
                initialize(count,0);
            }
        }
    }
    return;
}
