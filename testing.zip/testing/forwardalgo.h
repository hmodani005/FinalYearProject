#include<string>
using namespace std;
double forwardalgo(state * start, string input, string modelstring);
