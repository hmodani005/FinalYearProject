#include<stdio.h>
#include<iostream>
#include<vector>
#include<conio.h>
#include<algorithm>
#include<map>
#include<set>
#include "structure.h"
#define THRESHOLD 0.5
using namespace std;

double forwardalgo(state * start, string input, string modelstring)
{
	state* ins,*mat,*del, *prevmat=NULL, *prevdel=NULL, *previns=NULL;
	int t;
	for(t=0;t<=input.size();t++)
	{
		mat=start;
		ins=(start->toinsert).ptr ;
		del=NULL;
		previns=prevmat=prevdel=NULL;
		while(mat->type!='E')
		{
			double insprob=0.0, delprob=0.0, matprob=0.0;
			if(prevmat!=NULL)
			{
			    if(t>0)
				{
				    matprob += (prevmat->dp[t-1])* (prevmat->tomatch).prob;
				}
				delprob += (prevmat->dp[t]) * (prevmat->todelete).prob;
			}
			if(previns!=NULL)
			{
			    if(t>0)
				{
				    matprob += (previns->dp[t-1]) * (previns->tomatch).prob;
				}
				delprob += (previns->dp[t]) * (previns->todelete).prob;
			}
			if(prevdel!=NULL)
			{
				delprob += (prevdel->dp[t]) * (prevdel->todelete).prob;
				matprob += (prevdel->dp[t]) * (prevdel->tomatch).prob;
			}
			if(del!=NULL)
			{
				del->dp.push_back(delprob);
				insprob += del->dp[t] * (del->toinsert).prob;
			}
			if(ins!=NULL)
			{
			    if(t>0)
				{
				    insprob += ins->dp[t-1] * (ins->toinsert).prob;
				}
			}
			if(mat!=NULL)
			{
			    if(t>0)
				{
				    insprob += mat->dp[t-1] * (mat->toinsert).prob;
				}
			}
			if(t>0 && input[t-1]=='a' || input[t-1]=='A')
			{
				insprob *= ins->a;
				matprob *= mat->a;
			}
			else if(t>0 && input[t-1]=='c' || input[t-1]=='C')
			{
				insprob *= ins->c;
				matprob *= mat->c;
			}
			else if(t>0 && input[t-1]=='t' || input[t-1]=='T')
			{
				insprob *= ins->t;
				matprob *= mat->t;
			}
			else if(t>0 && input[t-1]=='g' || input[t-1]=='G')
			{
				insprob *= ins->g;
				matprob *= mat->g;
			}
			if(mat!=NULL)
			{
				if( mat->type == 'S' && t==0)
				{
					mat->dp.push_back(1.0);
				}
				else
				{
					mat->dp.push_back(matprob);
				}
 			}
 			if(ins!=NULL)
 			{
 				ins->dp.push_back(insprob);
 			}
 			prevmat=mat;
            previns=ins;
            prevdel=del;
            del= (mat->todelete).ptr;
            mat= (mat->tomatch).ptr;
            ins= (mat->toinsert).ptr;
		}
	}
	double score = 0.0;
	score += prevmat->dp[t-1] * (prevmat->tomatch).prob;
	score += previns->dp[t-1] * (previns->tomatch).prob;
	score += prevdel->dp[t-1] * (prevdel->tomatch).prob;
	return score;
}
