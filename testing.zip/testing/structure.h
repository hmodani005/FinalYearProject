#include<stdio.h>
#include<iostream>
#include<vector>
#include<conio.h>
#include<algorithm>
#include<map>
#include<set>
#define PSEUDO_TRANS_PROB 0.0
#define PSEUDO_EMI_PROB 0.0

typedef struct transitiontype
{
    struct statetype* ptr;
    double prob;
    transitiontype(): prob(PSEUDO_TRANS_PROB){}
} transition;

typedef struct statetype
{
    char type;
    std::vector<double> dp;
    struct transitiontype toinsert,todelete,tomatch;
    struct statetype *frominsert,*fromdelete,*frommatch;
    double a,c,t,g;
    statetype(): a(PSEUDO_EMI_PROB),c(PSEUDO_EMI_PROB),t(PSEUDO_EMI_PROB),g(PSEUDO_EMI_PROB) {}
} state;
