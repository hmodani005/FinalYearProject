
void initialize(vector<int> &vec, int val);
void calcemissionprob(state* start, vector<string> sequence, string modelstring);

